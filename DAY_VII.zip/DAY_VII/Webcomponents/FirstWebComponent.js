class HelloWorld extends HTMLElement {
  constructor() {
    super();
    console.log("Hello World Web Component !");
  }
}

// register the webcomponent
customElements.define("uc-helloworld", HelloWorld);

