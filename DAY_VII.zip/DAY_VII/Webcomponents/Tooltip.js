class Tooltip extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
  }

  connectedCallback() {
    const toolTipIcon = document.createElement("span");
    toolTipIcon.innerText = "(?)";
    this.shadowRoot.appendChild(toolTipIcon);
  }
}

customElements.define("uc-tooltip", Tooltip);
