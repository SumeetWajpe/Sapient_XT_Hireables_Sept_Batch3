// var MathModule = (function () {
//     function Add(x, y) {
//       return x + y;
//     }
//     function Product(x, y) {
//       return x * y;
//     }
//     return {
//       Addition: Add,
//       Multiplication: Product,
//     };
//   })();

var MathModule = { PI: 3.14 };

var MathModule = (function (MathModule) {
  MathModule.Add = function (x, y) {
    return x + y;
  };
  MathModule.Multiplication = function (x, y) {
    return x * y;
  };
  return MathModule;
})(MathModule || {});
