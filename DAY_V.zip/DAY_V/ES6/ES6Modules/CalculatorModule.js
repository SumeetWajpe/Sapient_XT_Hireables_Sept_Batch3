// import Multiplication, { Add } from "./MathModule.js";
// console.log(`The Multiplication is ${Multiplication(20, 40)}`);

import { Add as Addition } from "./MathModule.js";
console.log(`The addition is ${Addition(20, 40)}`);
