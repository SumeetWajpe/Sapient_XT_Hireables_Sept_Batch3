export function Add(x, y) {
  return x + y;
}

export default function Product(x, y) {
  return x * y;
}
