function GetPosts(callback) {
  // 1. instantiate XMLHttpRequest object
  // 2. open() -> httpverb, url
  // 3. register on onreadystatechange event
  // 4. send() -> makes the async call

  var xmlHttpReq = new XMLHttpRequest();
  xmlHttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
  xmlHttpReq.onreadystatechange = function () {
    if (xmlHttpReq.readyState === 4 && xmlHttpReq.status === 200) {
      console.log("Received Data returning to Index.html");

      callback(null, xmlHttpReq.responseText);
    } else if (xmlHttpReq.readyState === 4 && xmlHttpReq.status !== 200) {
      callback("Something went wrong !" + xmlHttpReq.status, null);
    }
  };
  console.log("Making async request !");

  xmlHttpReq.send();
}
