const express = require("express");
const app = express();
const path = require("path");
const courses = require("./models/course.model");

app.use(express.static(path.join(__dirname, "static")));
app.use(express.json());

app.get("/", (req, res) => res.sendFile("Courses.html", { root: __dirname }));
app.get("/courses", (req, res) => res.json(courses));
app.post("/newcourse", (req, res) => {
  // get the data from client
  let newCourseToBeAdded = req.body;
  courses.push(newCourseToBeAdded);

  // immutability (functional prog)
  // courses = [...courses, newCourseToBeAdded];

  res.json({ msg: "success" });
});
app.delete("/courses/:id", (req, res) => {
  let theCourseId = +req.params.id;
  let index = courses.findIndex((course) => course.id === theCourseId);
  courses.splice(index, 1);
  res.json({ msg: "success" });
});
app.listen(5000, () => console.log("Server running @ 5000 !"));
