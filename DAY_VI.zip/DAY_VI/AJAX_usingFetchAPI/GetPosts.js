function GetPosts() {
  return fetch("https://jsonplaceholder.typicode.com/postsss");
}
