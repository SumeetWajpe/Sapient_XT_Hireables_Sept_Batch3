// No access to document | window
// No access to global variable from main thread !
// Access to XMLHttpRequest object -> AJAX | fetch
// No access to localStorage | sessionStorage, but access to IndexedDB

// console.log(this); // DedicatedWorkerGlobalScope

var largeArray = [];
onmessage = function (dataFromMainThread) {
  console.log("Data From main thread : ", dataFromMainThread.data);
  for (let i = 0; i < 6000; i++) {
    largeArray[i] = [];
    for (let j = 0; j < 8000; j++) {
      largeArray[i][j] = Math.random();
    }
  }
  postMessage(largeArray[2000][2000]);
  largeArray = null; //=> memory to be free !
};

// var largeArray = [];
// function PerformHeavyLifting() {
//   for (let i = 0; i < 6000; i++) {
//     largeArray[i] = [];
//     for (let j = 0; j < 8000; j++) {
//       largeArray[i][j] = Math.random();
//     }
//   }
//   alert(largeArray[2000][2000]);
// }
